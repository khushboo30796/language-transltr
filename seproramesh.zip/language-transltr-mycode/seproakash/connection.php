<?php

$h="localhost";
$u="root";
$p="ramesh";
$d="portal";

$conn=new mysqli($h,$u,$p,$d);

?>
