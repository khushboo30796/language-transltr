<?php
require_once('Admin.php');
$obj=new Admin();
$obj->assignTranslation('Test');
?>