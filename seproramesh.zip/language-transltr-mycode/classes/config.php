<?php
define("DB_DSN","mysql:host=127.0.0.1;dbname=my_database");
define("DB_USERNAME","root");
define("DB_PASSWORD","");
?>
