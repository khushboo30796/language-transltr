<?php

$h='127.0.0.1';
$u='root';
$p='';
$d='my_database';

$conn=new mysqli($h,$u,$p,$d);

?>
