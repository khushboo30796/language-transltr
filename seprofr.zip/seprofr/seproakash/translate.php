<?php

include "connection.php";

?>
<p align="right"><a href="loginhome1.php">Home</a>  &nbsp; &nbsp;
<center>
<h2>Indian Institute of Technology,Indore</h2>
<h1>KSHIP</h1>
<h3>View Research Papers and Projects</h3>
<body style="background-image :url(iitilogo-2.png);
		background-repeat: no-repeat;
		background attachment: fixed;
		background-position: 50% 28%;
		background-size: 500px 800px
		">
</body>

<h5>We are still working on the algorithm for the crowdsource model framework.</h5>

<h5>See you soon!</h5>
