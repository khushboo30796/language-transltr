<?php

$h='localhost';
$u='root';
$p='';
$d='portal';

$conn=new mysqli($h,$u,$p,$d);

?>
