
<?php

echo mime_content_type('Tut1.exe') . "\n";
echo mime_content_type('tut-4.pdf');

?>


